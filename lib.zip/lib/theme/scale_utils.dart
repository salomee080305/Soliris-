import 'package:flutter/widgets.dart';

extension AppScale on num {
  /// Scales by the global textScaleFactor (0.9–1.6).
  double sx(BuildContext context) =>
      this * MediaQuery.textScaleFactorOf(context).clamp(0.9, 1.6);
}