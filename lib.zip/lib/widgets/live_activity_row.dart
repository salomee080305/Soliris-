import 'package:flutter/material.dart';
import '../realtime_service.dart' show realtime;
import 'health_metric_card.dart';

class LiveActivityRow extends StatefulWidget {
  const LiveActivityRow({super.key});

  @override
  State<LiveActivityRow> createState() => _LiveActivityRowState();
}

class _LiveActivityRowState extends State<LiveActivityRow> {
  int? _steps;            // total steps (today / cumul)
  String? _postureLabel;  // Standing / Sitting / Walking…

  // --- helpers parsing ---
  Map<String, dynamic> _asMap(dynamic v) {
    if (v is Map) return v.map((k, val) => MapEntry(k.toString(), val));
    return const {};
  }
  num? _num(dynamic v) {
    if (v is num) return v;
    if (v is String) return num.tryParse(v);
    return null;
  }
  String? _str(dynamic v) => v == null ? null : v.toString();

  String? _mapPosture(dynamic raw) {
    // string labels
    final s = _str(raw)?.toLowerCase();
    if (s != null) {
      switch (s) {
        case 'stand':
        case 'standing':
          return 'Standing';
        case 'sit':
        case 'sitting':
          return 'Sitting';
        case 'lie':
        case 'lying':
        case 'supine':
          return 'Lying';
        case 'walk':
        case 'walking':
          return 'Walking';
        case 'run':
        case 'running':
          return 'Running';
        case 'fall':
        case 'fallen':
          return 'Fall';
      }
    }
    // numeric codes (exemples)
    final n = _num(raw)?.toInt();
    if (n != null) {
      switch (n) {
        case 1:
          return 'Standing';
        case 2:
          return 'Sitting';
        case 3:
          return 'Lying';
        case 4:
          return 'Walking';
        case 5:
          return 'Running';
      }
    }
    return null;
  }

  void _ingest(Map<String, dynamic> msg) {
    final tel = _asMap(msg['telemetry']);
    final m   = _asMap(tel['m']); // au cas où tu nestes les valeurs sous "m"

    // ---- Steps (prend la meilleure source dispo) ----
    final steps =
        _num(tel['steps_today']) ??
        _num(tel['steps_total']) ??
        _num(tel['steps']) ??
        _num(m['steps_today']) ??
        _num(m['steps_total']) ??
        _num(m['steps']);
    if (steps != null) _steps = steps.toInt();

    // ---- Posture / Activity ----
    final postureRaw =
        tel['posture'] ?? tel['activity'] ?? m['posture'] ?? m['activity'];
    final label = _mapPosture(postureRaw);
    if (label != null) _postureLabel = label;
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: realtime.stream,
      builder: (context, snap) {
        if (snap.hasData) {
          final msg = _asMap(snap.data);
          _ingest(msg);
        }
        return Row(
          children: [
            HealthMetricCard(
              title: 'Steps',
              value: _steps == null ? '--' : _steps!.toString(),
              icon: Icons.directions_walk,
            ),
            const SizedBox(width: 12),
            HealthMetricCard(
              title: 'Posture',
              value: _postureLabel ?? '—',
              icon: Icons.accessibility_new,
            ),
          ],
        );
      },
    );
  }
}