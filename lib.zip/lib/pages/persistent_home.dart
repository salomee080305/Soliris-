// lib/pages/home_navigator.dart
import 'package:flutter/material.dart';
import 'dashboard_page.dart';
import 'documentation_page.dart';
import 'health_dashboard_pages.dart'; 
import 'sun_page.dart';
import 'profile_page.dart';
// import '../widgets/bottom_nav_bar.dart'; // si tu as un BottomNavBar custom

class HomeNavigator extends StatefulWidget {
  const HomeNavigator({super.key});
  @override
  State<HomeNavigator> createState() => _HomeNavigatorState();
}

class _HomeNavigatorState extends State<HomeNavigator> {
  int _index = 0;

  // ⚠️ crée les pages UNE FOIS, pas dans build()
  final List<Widget> _pages = const [
    DashboardPage(),
    DocumentationPage(),      // "Health Metrics"
    // HealthDashboardPage(),  // ← si c’est cette page que tu utilises pour le graphe
    SunPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // ✅ garde chaque page en mémoire
      body: IndexedStack(index: _index, children: _pages),

      // utilise ton BottomNavigationBar (natif)…
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Health'),
          BottomNavigationBarItem(icon: Icon(Icons.wb_sunny), label: 'Sun'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),

      // …ou ton widget custom si tu en as un :
      // bottomNavigationBar: BottomNavBar(
      //   currentIndex: _index,
      //   onTap: (i) => setState(() => _index = i),
      // ),
    );
  }
}