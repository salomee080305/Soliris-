import 'dart:convert';
import 'package:http/http.dart' as http;

import 'soliris_ble.dart'; // imports the global `solirisBle`

// ===== Configure for your setup =====
// A. Simulator / proxy backend (recommended for iOS Simulator)
const String backendBase = 'http://192.168.1.26:5050'; // or your Mac IP on real device

// B. (Optional) direct ESP32 HTTP (if your firmware exposes /ctrl)
/* Example:
const String? deviceIp = 'http://192.168.1.42';
*/
const String? deviceIp = null;

/// Send a control JSON to the device:
/// - If BLE is connected (real iPhone): write to the control characteristic.
/// - Else if a backend is set (simulator): POST to /device/ctrl.
/// - Else if deviceIp is set: POST directly to the ESP32.
/// Throws on HTTP errors.
Future<void> deviceCtrl(Map<String, dynamic> j) async {
  // 1) Try BLE (real device)
  try {
    if (solirisBle.isConnected) {
      await solirisBle.sendCtrl(j);
      return;
    }
  } catch (_) {
    // ignore and fall back to HTTP
  }

  // 2) HTTP fallback to backend (simulator)
  if (backendBase.isNotEmpty) {
    final uri = Uri.parse(
        deviceIp == null ? '$backendBase/device/ctrl' : '$backendBase/device/ctrl?ip=$deviceIp');
    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: json.encode(j),
    );
    if (res.statusCode >= 300) {
      throw Exception('HTTP ${res.statusCode}: ${res.body}');
    }
    return;
  }

  // 3) Direct HTTP to ESP32 (if you expose /ctrl on firmware)
  if (deviceIp != null) {
    final uri = Uri.parse('$deviceIp/ctrl');
    final res = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: json.encode(j),
    );
    if (res.statusCode >= 300) {
      throw Exception('HTTP ${res.statusCode}: ${res.body}');
    }
    return;
  }

  throw StateError('No route to device (BLE not connected, no backend/deviceIp configured).');
}