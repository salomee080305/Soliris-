// lib/main.dart
import 'package:flutter/material.dart';
import 'theme/theme_controller.dart';        // ThemeController.instance
import 'pages/welcome_screen.dart';
import 'pages/home_navigator.dart';
import 'profile_store.dart';

// Realtime + alerts
import 'realtime_service.dart' show realtime;
import 'alert_center.dart';

// ↙️ Démo : forcer l'onboarding à chaque lancement
const bool kDemoResetOnStart = true;
// Astuce prod : passe en variable d'env si besoin
// const bool kDemoResetOnStart = bool.fromEnvironment('DEMO_RESET', defaultValue: false);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Charger l'historique d'alertes pour avoir le badge correct dès la 1ère frame
  await AlertCenter.instance.init();

  if (kDemoResetOnStart) {
    // Demo: on vide le profil pour forcer l'onboarding
    await ProfileStore.instance.clear();
  } else {
    // Prod: on recharge le profil existant
    await ProfileStore.instance.load();
  }

  runApp(const SolirisApp());
}

class SolirisApp extends StatefulWidget {
  const SolirisApp({super.key});
  @override
  State<SolirisApp> createState() => _SolirisAppState();
}

class _SolirisAppState extends State<SolirisApp> {
  @override
  void initState() {
    super.initState();
    // Démarrer le flux temps réel une seule fois
    realtime.connect();
    // Brancher la cloche sur le flux
    AlertCenter.instance.bindTo(realtime.stream);
  }

  @override
  void dispose() {
    AlertCenter.instance.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 1) Écoute du mode clair/sombre
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: ThemeController.instance.mode,
      builder: (_, mode, __) {
        // 2) Écoute de l’échelle globale (0.9–1.6)
        return ValueListenableBuilder<double>(
          valueListenable: ThemeController.instance.textScale,
          builder: (_, scaleRaw, __) {
            final double scale = scaleRaw.clamp(0.9, 1.6);

            return MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'Soliris',

              // Thèmes centralisés (voir theme_controller.dart v2)
              theme: ThemeController.instance.light,
              darkTheme: ThemeController.instance.dark,
              themeMode: mode,

              // Couche de scaling globale (texte + AppBar + icônes)
              builder: (context, child) {
                // Texte : applique l’échelle
                final mq = MediaQuery.of(context).copyWith(
                  textScaleFactor: scale,
                );

                // Ajuste AppBar (hauteur, titre, icônes) et IconTheme par défaut
                final base = Theme.of(context);
                final appBar = base.appBarTheme;

                final newAppBar = appBar.copyWith(
                  toolbarHeight: (appBar.toolbarHeight ?? 56) * scale,
                  titleTextStyle: (appBar.titleTextStyle ??
                          base.textTheme.titleLarge ??
                          const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))
                      .copyWith(
                    fontSize: ((appBar.titleTextStyle?.fontSize) ??
                            base.textTheme.titleLarge?.fontSize ??
                            20) *
                        scale,
                  ),
                  iconTheme: (appBar.iconTheme ?? base.iconTheme).copyWith(
                    size: ((appBar.iconTheme?.size) ?? base.iconTheme.size ?? 24) * scale,
                  ),
                );

                final themed = base.copyWith(
                  appBarTheme: newAppBar,
                  iconTheme: base.iconTheme.copyWith(
                    size: (base.iconTheme.size ?? 24) * scale,
                  ),
                );

                // ⚠️ Pas d’IconTheme wrapper additionnel ici pour éviter le double scaling
                return MediaQuery(
                  data: mq,
                  child: Theme(data: themed, child: child!),
                );
              },

              // Onboarding si pas de profil, sinon Home
              home: ValueListenableBuilder(
                valueListenable: ProfileStore.instance.profile,
                builder: (context, profile, _) {
                  return profile == null
                      ? const WelcomeScreen()
                      : const HomeNavigator();
                },
              ),
            );
          },
        );
      },
    );
  }
}